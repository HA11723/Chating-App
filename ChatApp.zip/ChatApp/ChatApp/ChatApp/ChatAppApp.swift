//
//  ChatAppApp.swift
//  ChatApp
//
//  Created by Hadi Nasir on 2025-01-03.
//

import SwiftUI

@main
struct ChatAppApp: App {
    var body: some Scene {
        WindowGroup {
            MainMessagesView()
        }
    }
}
