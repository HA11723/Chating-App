//  ContentView.swift
//  ChatApp
//
//  Created by Hadi Nasir on 2025-01-03.
//

import SwiftUI
import Firebase

struct ContentView: View {
    
    let didCompleteLooinProcess: () -> ()
    
    @State private var isLoginMode = false
    @State private var email = ""
    @State private var password = ""
    @State private var username = "" // New username field
    @State private var age = ""
    @State private var location = ""
    @State private var shouldShowImagePicker = false
    @State private var image: UIImage? // Profile picture
    @State private var loginStatusErrorMessage = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    Picker(selection: $isLoginMode, label: Text("Picker here")) {
                        Text("Login")
                            .tag(true)
                        Text("Create Account")
                            .tag(false)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                    if !isLoginMode {
                        Button {
                            shouldShowImagePicker.toggle()
                        } label: {
                            VStack {
                                if let image = self.image {
                                    Image(uiImage: image)
                                        .resizable()
                                        .frame(width: 128, height: 128)
                                        .scaledToFill()
                                        .cornerRadius(64)
                                } else {
                                    Image(systemName: "person.fill")
                                        .font(.system(size: 64))
                                        .padding()
                                        .foregroundColor(Color(.label))
                                }
                            }
                            .overlay(RoundedRectangle(cornerRadius: 64)
                                .stroke(Color.black, lineWidth: 3))
                        }
                    }
                    
                    Group {
                        if !isLoginMode {
                            TextField("Username", text: $username) // New username input
                                .autocapitalization(.none)
                                .padding(12)
                                .background(Color.white)
                            
                            TextField("Age", text: $age)
                                .keyboardType(.numberPad)
                                .padding(12)
                                .background(Color.white)
                            
                            TextField("Location", text: $location)
                                .autocapitalization(.none)
                                .padding(12)
                                .background(Color.white)
                        }
                    }
                    // Email and password inputs
                    Group {
                        TextField("Email", text: $email)
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                            .padding(12)
                            .background(Color.white)
                        
                        SecureField("Password", text: $password)
                            .padding(12)
                            .background(Color.white)
                    }
                    
                    
                    Button {
                        handleAction()
                    } label: {
                        HStack {
                            Spacer()
                            Text(isLoginMode ? "Log In" : "Create Account")
                                .foregroundColor(.white)
                                .padding(.vertical, 10)
                                .font(.system(size: 14, weight: .semibold))
                            Spacer()
                        }
                        .background(Color.blue)
                    }
                    
                    Text(self.loginStatusErrorMessage)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                }
                .padding()
            }
            .navigationTitle(isLoginMode ? "Log In" : "Create Account")
            .background(Color(.init(white: 0, alpha: 0.05)).ignoresSafeArea())
            .alert(isPresented: $showAlert) { //displaying ther alert
                Alert(title: Text("Missing Information"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .fullScreenCover(isPresented: $shouldShowImagePicker, onDismiss: nil) {
            ImagePicker(image: $image) // Ensure ImagePicker is implemented
        }
    }
    
    private func handleAction() {
        if isLoginMode {
            loginUser()
        } else {
            createNewAccount()
        }
    }
    
    private func loginUser() {
        FirebaseManager.shared.auth.signIn(withEmail: email, password: password) { result, err in
            if let err = err {
                print("Failed to log in user: \(err)")
                self.loginStatusErrorMessage = "Failed to log in user: \(err.localizedDescription)"
                return
            }
            
            print("Successfully logged in user: \(result?.user.uid ?? "")")
            
            self.loginStatusErrorMessage = "Successfully logged in user: \(result?.user.uid ?? "")"
            
            self.didCompleteLooinProcess()
        }
    }
    
    private func createNewAccount() {
        // Validate all required fields
        guard !username.isEmpty else {
            alertMessage = "Please enter your username."
            showAlert = true
            return
        }
        
        guard !age.isEmpty else {
            alertMessage = "Please enter your age."
            showAlert = true
            return
        }
        
        guard !location.isEmpty else {
            alertMessage = "Please enter your location."
            showAlert = true
            return
        }
        
        guard let _ = image else {
            alertMessage = "Please select a profile image."
            showAlert = true
            return
        }
        
        guard !email.isEmpty else {
            alertMessage = "Please enter your email."
            showAlert = true
            return
        }
        
        guard !password.isEmpty else {
            alertMessage = "Please enter your password."
            showAlert = true
            return
        }
        
        // Proceed with account creation
        FirebaseManager.shared.auth.createUser(withEmail: email, password: password) { result, err in
            if let err = err {
                print("Failed to create user: \(err)")
                self.loginStatusErrorMessage = "Failed to create user: \(err.localizedDescription)"
                return
            }

            guard let uid = result?.user.uid else {
                print("Failed to retrieve user ID")
                self.loginStatusErrorMessage = "Failed to retrieve user ID."
                return
            }

            // Save user data to Firestore
            let userData: [String: Any] = [
                "uid": uid,
                "email": self.email,
                "username": self.username,
                "age": self.age,
                "location": self.location
            ]
            
            FirebaseManager.shared.firestore.collection("users")
                .document(uid).setData(userData) { err in
                    if let err = err {
                        print("Failed to save user data: \(err)")
                        self.loginStatusErrorMessage = "Failed to save user data: \(err.localizedDescription)"
                        return
                    }
                    print("Successfully saved user data to Firestore!")
                }
        }
    }

 
    
    private func persistImageToStorage(uid: String) {
        guard let imageData = self.image?.jpegData(compressionQuality: 0.5) else {
            self.storeUserInformation(uid: uid, profileImageUrl: nil)
            return
        }
        
        let ref = FirebaseManager.shared.storage.reference(withPath: uid)
        ref.putData(imageData, metadata: nil) { _, err in
            if let err = err {
                print("Failed to upload image: \(err)")
                self.loginStatusErrorMessage = "Failed to upload image: \(err.localizedDescription)"
                return
            }
            
            ref.downloadURL { url, err in
                if let err = err {
                    print("Failed to retrieve download URL: \(err)")
                    self.loginStatusErrorMessage = "Failed to retrieve download URL: \(err.localizedDescription)"
                    return
                }
                
                guard let url = url else { return }
                self.storeUserInformation(uid: uid, profileImageUrl: url.absoluteString)
            }
        }
    }
    
    private func storeUserInformation(uid: String, profileImageUrl: String?) {
        var userData: [String: Any] = [
            "uid": uid,
            "email": email,
            "username": username // Save username
        ]
        
        if let profileImageUrl = profileImageUrl {
            userData["profileImageUrl"] = profileImageUrl
        }
        
        FirebaseManager.shared.firestore.collection("users")
            .document(uid).setData(userData) { err in
                if let err = err {
                    print("Failed to save user data: \(err)")
                    self.loginStatusErrorMessage = "Failed to save user data: \(err.localizedDescription)"
                    return
                }
                
                print("Successfully saved user data to Firestore!")
                self.didCompleteLooinProcess()
            }
    }
}

// You need to define or import ImagePicker view if you haven't already.
#Preview {
    ContentView(didCompleteLooinProcess: {
        
    })
}
