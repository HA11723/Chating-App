//
//  RecentMessage.swift
//  ChatApp
//
//  Created by Hadi Nasir on 2025-01-05.
//

import Foundation
import Firebase
import FirebaseFirestore


struct RecentMessage: Identifiable {
    var id: String { documentId }
    let documentId: String
    let username: String
    let text, email: String
    let fromId, toId: String
    let timestamp: Date

    var timeAgo: String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: timestamp, relativeTo: Date())
    }

    init(documentId: String, data: [String: Any]) {
        self.documentId = documentId
        self.text = data["text"] as? String ?? ""
        self.fromId = data["fromId"] as? String ?? ""
        self.toId = data["toId"] as? String ?? ""
        self.email = data["email"] as? String ?? ""
        self.username = data["username"] as? String ?? "HI" // Default if missing
        self.timestamp = (data["timestamp"] as? Timestamp)?.dateValue() ?? Date()
    }
}
