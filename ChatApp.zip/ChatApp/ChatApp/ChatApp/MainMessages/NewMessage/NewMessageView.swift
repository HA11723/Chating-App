//
//  NewMessageView.swift
//  ChatApp
//
//  Created by Hadi Nasir on 2025-01-04.
//

import SwiftUI
import SDWebImage

class  NewMessageViewModel: ObservableObject {
    //Storing the users from the firestore
    @Published var users = [ChatUser]()
    @Published var username = [ChatUser]()

    @Published var errorMessage = ""
    
    
    
    init() {
        fetchAllUsers()
    }
    
    private func fetchAllUsers() {
        FirebaseManager.shared.firestore.collection("users")
            .getDocuments { documentsSnapshots, error in
                if let error = error {
                    self.errorMessage = "faold to fetch users: \(error)"
                    print("faold to fetch users: \(error)")
                    return
                }
                
                
                documentsSnapshots?.documents.forEach({ snapshot in
                    let data = snapshot.data()
                    let user = ChatUser(data: data)
                    if user.uid !=
                        FirebaseManager.shared.auth.currentUser?.uid {
                        self.users.append(.init(data: data))
                    }
                   
                })
                
            //    self.errorMessage = "Fetched users success"
            }
    }
    
}
    
    struct NewMessageView: View {
        
        let didSelectNewUser: (ChatUser) -> ()
        
        @Environment(\.presentationMode) var presentationMode
        
        @ObservedObject var vm = NewMessageViewModel()
        
        var body: some View {
            NavigationView {
                ScrollView {
                    Text(vm.errorMessage)
                    //printing the username on the screen from the firestore
                    ForEach(vm.users) { user in
                        Button {
                            presentationMode.wrappedValue.dismiss()
                            didSelectNewUser(user)
                        } label: {
                            HStack(spacing: 16) {
                               // WebImage(url: URL(String: user.profileImageUrl))
                                Image(systemName: "person.circle.fill")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 50, height: 50)
                                    .clipped()
                                    .cornerRadius(50)
                                    .overlay(RoundedRectangle(cornerRadius: 50)
                                        .stroke(Color(.blue),
                                                lineWidth: 4)
                                    )
                                Text(user.username)
                                    .foregroundColor(Color(.label))
                                    Spacer()
                            }.padding(.horizontal)
                           
                        }
                        Divider()
                            .padding(.vertical, 8)
                      
                    }
                }.navigationTitle("New Message")
                    .toolbar {
                        ToolbarItemGroup(placement: .navigationBarLeading) {
                            Button {
                                presentationMode.wrappedValue.dismiss() // Corrected spelling
                                
                            } label: {
                                Text("Cancel")
                            }
                        }
                    }
                
            }
        }
    }
    
    
    #Preview {
      //  NewMessageView()
         MainMessagesView()
        
    }

