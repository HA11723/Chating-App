

//
//  MainMessagesView.swift
//  ChatApp
//
//  Created by Hadi Nasir on 2025-01-03.
//

import SwiftUI
import SDWebImage
import Firebase



class MainMessagesViewmodel: ObservableObject {
        
        @Published var errorMessage = ""
        @Published var chatUser: ChatUser?
        
        init() {
            
            DispatchQueue.main.async {
                self.isUserCurrentlyLoggedOut =
                FirebaseManager.shared.auth.currentUser?.uid == nil
                
            }
            
            fetchCurrentUser()
            
            fetchRecentMessages()
        }
        
    @Published var recentMessages = [RecentMessage]()
    
    private var firestoreListener: ListenerRegistration?
        
    func fetchRecentMessages() {
        guard let uid = FirebaseManager.shared.auth.currentUser?.uid else {
            return
        }
        
        self.recentMessages.removeAll()

        FirebaseManager.shared.firestore
            .collection("recent_messages")
            .document(uid)
            .collection("messages")
            .order(by: "timestamp")
            .addSnapshotListener { querySnapshot, error in
                if let error = error {
                    self.errorMessage = "Failed to listen to recent messages: \(error)"
                    print(error)
                    return
                }

                querySnapshot?.documentChanges.forEach({ change in
                    let docId = change.document.documentID

                    if let index = self.recentMessages.firstIndex(where: { $0.documentId == docId }) {
                        self.recentMessages.remove(at: index)
                    }

                    let data = change.document.data()
                    if let username = data["username"] as? String {
                        print("Fetched username for recent message: \(username)")
                    } else {
                        print("No username found in recent message data.")
                    }

                    self.recentMessages.insert(.init(documentId: docId, data: data), at: 0)
                })
            }
    }

        func fetchCurrentUser() {
            
            guard let uid = FirebaseManager.shared.auth.currentUser?.uid else {
                self.errorMessage = "Could not find Firebase UID"
                return
            }
            
            FirebaseManager.shared.firestore.collection("users")
                .document(uid).getDocument { snapshot, error in
                    if let error = error {
                        self.errorMessage = "Failed to fetch current user: \(error.localizedDescription)"
                        print("Failed to fetch current user:", error)
                        return
                    }
                    
                    guard let data = snapshot?.data() else {
                        self.errorMessage = "No user data found in Firestore for UID: \(uid)"
                        print("No user data found for UID:", uid)
                        return
                    }
                    
                    self.chatUser = .init(data: data)
                    
                    
                }
        }
        
        //This is for making the logout button to work when clicked
        @Published var isUserCurrentlyLoggedOut = false
        
        func handleSignOut() {
            isUserCurrentlyLoggedOut.toggle()
            try? FirebaseManager.shared.auth.signOut()
        }
        
    }
    
    struct MainMessagesView: View {
        
        @State var shouldShowLogOutOptions = false
        @State var shouldNavigateToChatLogView = false
        
        @ObservedObject private var vm = MainMessagesViewmodel()
        
        
        var body: some View {
            NavigationView {
                
                
                VStack {
                    //              Text("User: \(vm.chatUser?.uid ?? "")")
                    customNavBar
                    messagesView
                    
                    NavigationLink("", isActive: $shouldNavigateToChatLogView) {
                        ChatLogView(chatUser: self.chatUser)
                    }
                }
                .overlay(
                    newMessageButton,
                    alignment: .bottom
                )
                .navigationBarHidden(true)
            }
        }
        
        private var customNavBar: some View {
            HStack(spacing: 16) {
                
                //this is for printing the profile image for the user
                //WebImage(url: URL(string: vm.chatUser?.profileImageUrl ?? ""))
                //  .resizable()
                //  .scaledToFill()
                //  .frame(width: 50, height:50)
                //  .clipped()
                //.cornerRadius(50)
                //.overlay(
                //   RoundedRectangle(cornerRadius: 44)
                //       .stroke(Color(UIColor.label), lineWidth: 1)
                // )
                
                Image(systemName: "person.fill")
                    .font(.system(size: 34, weight: .heavy))
                
                VStack(alignment: .leading, spacing: 4) {
                    
                    //this will print the user email in the screen
                    if let email = vm.chatUser?.username {
                        Text(email)
                            .font(.system(size: 24, weight: .bold))
                    } else {
                        Text("Loading...")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.gray)
                    }
                    
                    HStack {
                        Circle()
                            .foregroundColor(.green)
                            .frame(width: 14, height: 14)
                        Text("Online")
                            .font(.system(size: 12))
                            .foregroundColor(Color(UIColor.lightGray))
                    }
                }
                
                Spacer()
                Button {
                    shouldShowLogOutOptions.toggle()
                } label: {
                    Image(systemName: "gear")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(Color(UIColor.label))
                }
            }
            .padding()
            .actionSheet(isPresented: $shouldShowLogOutOptions) {
                ActionSheet(
                    title: Text("Settings"),
                    message: Text("What do you want to do?"),
                    buttons: [
                        .destructive(Text("Sign Out"), action: {
                            print("Handle sign out")
                            vm.handleSignOut()
                        }),
                        .cancel()
                    ]
                )
            }
            .fullScreenCover(isPresented: $vm.isUserCurrentlyLoggedOut, onDismiss: nil) {
                ContentView(didCompleteLooinProcess: {
                    self.vm.isUserCurrentlyLoggedOut = false
                    self.vm.fetchCurrentUser()
                    self.vm.fetchRecentMessages()
                })
            }
        }
        
        private var messagesView: some View {
            ScrollView {
                //the vm thing will print the recent messages
                ForEach(vm.recentMessages) { recentMessage in
                    VStack {
                        NavigationLink {
                            Text("destnation")
                        } label: {
                            HStack(spacing: 16) {
                                //                               WebImage(url: URL(string: recentMessage.profileImageUrl))
                                //                               .resizable()
                                //                               .scaledToFill()
                                //                            .frame(width: 64, height: 64)
                                //                          .clipped()
                                //                      .cornerRadius(64)
                                //                       .overlay(RoundedRectangle(cornerRadius: 64)
                                //                           .stroke(Color.black, lineWidth: 1))
                                ///                     .shadow(radius: 5)
                                
                                
                                Image(systemName: "person.fill")
                                    .font(.system(size: 34))
                                    .padding(8)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 44)
                                            .stroke(Color(UIColor.label), lineWidth: 1)
                                    )
                                //priting the email
                                VStack(alignment: .leading, spacing: 8) {
                                    Text(recentMessage.username)
                                        .font(.system(size: 16, weight: .bold))
                                        .foregroundColor(Color(.label))
                                        .multilineTextAlignment(.leading)

                                    Text(recentMessage.text)
                                        .font(.system(size: 14))
                                        .foregroundColor(Color(UIColor.darkGray))
                                        .multilineTextAlignment(.leading)
                                }
                                
                                Spacer()
                                
                                Text(recentMessage.timeAgo.description)
                                    .font(.system(size: 14, weight: .semibold))
                                    .multilineTextAlignment(.leading)

                            }
                        }
                        
                        
                        Divider()
                            .padding(.vertical, 8)
                    }
                    .padding(.horizontal)
                }
                .padding(.bottom, 50)
            }
        }
        
        @State var shouldShowNewMessageScreen = false
        
        private var newMessageButton: some View {
            Button {
                shouldShowNewMessageScreen.toggle()
            } label: {
                HStack {
                    Spacer()
                    Text("+ New Message")
                        .font(.system(size: 16, weight: .bold))
                    Spacer()
                }
                .foregroundColor(.white)
                .padding(.vertical)
                .background(Color.blue)
                .cornerRadius(32)
                .padding(.horizontal)
                .shadow(radius: 15)
            }
            .fullScreenCover(isPresented: $shouldShowNewMessageScreen) {
                NewMessageView(didSelectNewUser: { user
                    in
                    print(user.username)
                    self.shouldNavigateToChatLogView.toggle()
                    self.chatUser = user
                })
            }
        }
        
        @State var chatUser: ChatUser?
    }

    #Preview {
        MainMessagesView()
    }

